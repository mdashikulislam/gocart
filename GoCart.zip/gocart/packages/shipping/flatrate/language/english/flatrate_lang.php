<?php

$lang['rate']	= 'Rate';
$lang['val_err']	= 'The rate must be a numerical value.';