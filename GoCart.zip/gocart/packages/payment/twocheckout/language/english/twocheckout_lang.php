<?php

$lang['twocheckout']				= '2Checkout';

//twocheckout library messages
$lang['twocheckout_error']				= 'There was an error processing your payment through 2Checkout';
$lang['twocheckout_desc']				= 'You will be directed to 2Checkout to complete your payment. Once your payment is authorized, you will be directed back to our website and your order will be complete.';


//twocheckout admin
$lang['sid']				            = '2Checkout Account Number';
$lang['secret']				            = '2Checkout Secret Word';

$lang['currency_label']				    = 'USD, EUR, etc.';