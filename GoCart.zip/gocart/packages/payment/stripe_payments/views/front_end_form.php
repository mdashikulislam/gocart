<table width="100%" border="0" cellpadding="5">
    <tr>
        <td><img style="width: 180px"  src="https://i.ibb.co/yh0vPSD/stripe-icon-23-1.png" border="0" alt="Acceptance Mark"></td>
    </tr>
    <tr>
        <td>
            You will be directed to the stripe website to verify your payment. Once your payment is authorized, you will be directed back to our website and your order will be complete.</td>
    </tr>
</table>